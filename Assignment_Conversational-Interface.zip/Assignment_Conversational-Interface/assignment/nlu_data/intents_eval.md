## intent:greet
- yo

## intent: results_query
- give me the results for [Chelsea](team)
- do you know about [Newcastle](team)
- give me the results for [Ipswich](team)
- [Tottenham](team)
- do you know about [Norwich](team)
- give me the results for [QPR](team)
