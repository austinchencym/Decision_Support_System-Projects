## intent:greet
- hey
- hello there
- hi
- hello there
- good morning
- good evening
- hey there
- let's go
- hey dude
- goodmorning
- goodevening
- good afternoon

## intent:goodbye
- see you
- good by
- cee you later
- good night
- good afternoon
- bye
- goodbye
- have a nice day
- see you around
- bye bye
- see you later
- good bye

## intent:affirm
- yes
- indeed
- of course
- that sounds good
- correct
- definitely
- absolutely
****- sure
- yep

## intent:deny
- no
- never
- I don't think so
- don't like that
- no way
- not really
- nope
- definitely no
- no no

## intent:thanks
- thanks
- thank you
- thank you very much
- thanks a lot
- thank you so much
- thank you loads
- tnx

## intent:premisetype_check
- is there any crime happened in [apartment](premisetype)
- any crime happened in [house](premisetype)
- do you have crime data in [apartment](premisetype)
- i want crime info in [outside](premisetype)
- [commerical](premisetype) crime data
- criminal info in premise where [apartment](premisetype)
- premisetype [house](premisetype)
- is there any crime happened in [house](premisetype)

## intent: month_week_result
- give me the week and month crime results for [wednesday](weekday) in [january](month)
- do you have weekday crime results data in [march](month)
- do you know about data in month [august](month)
- how is [march](month) doing for each day?
- how is everyday doing in [april](month)
- how many crimes are there on [friday](weekday) in [june](month)
- I want results for month [july](month)

## intent: rank_result
- what is the [most frequent](rank)crime in neighbor [danforth](neighbor) from [2015](year_from) to [2017](year_to)
- [rank](rank) 1 crime for neighbor [annex](neighbor)
- [most](rank) dangerous crime for neighbor [danforth](neighbor)
- [top](rank) crime status.
- [worst](rank) crime for neighbor from [2015](year_from) to [2017](year_to)
- i want the info about the [most frequent](rank)crime 


## intent:inform
- [monday](weekday)
- [tuesday](weekday)
- [wednesday](weekday)
- [thursday](weekday)
- [friday](weekday)
- [saturday](weekday)
- [sunday](weekday)
- [january](month)
- [february](month)
- [march](month)
- [april](month)
- [may](month)
- [june](month)
- [july](month)
- [august](month)
- [september](month)
- [october](month)
- [november](month)
- [december](month)
- [annex](neighbor)
- [university](neighbor)
- [mimico](neighbor)
- [woburn](neighbor)
- [thorncliffe park](neighbor)
- [west hill](neighbor)
- [bathurst manor](neighbor)
- [new toronto](neighbor)
- [morningside](neighbor)
- from [2015](year_from) to [2016](year_to)
- from [2015](year_from) to [2017](year_to)
- from [2016](year_from) to [2017](year_to)
- from [2015](year_from) to [2016](year_to)

## intent: out_of_scope
- hehe
- haha
- chen yi ming
- austin is good
- viola is good
- weather is not good
- let us try this out



