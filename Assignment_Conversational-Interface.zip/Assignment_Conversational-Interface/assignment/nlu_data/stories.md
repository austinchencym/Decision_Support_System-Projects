## Greet
* greet 
    - utter_greet

## Thanks
* thanks
    - utter_np

## Goodbye
* goodbye
    - utter_goodbye
    - action_restart

## premisetype 1
* premisetype_check{"premisetype": "apartment"}
    - action_check_premisetype
* thanks
    - utter_np
    - action_restart
    
## premisetype 2
* premisetype_check{"premisetype": "house"}
    - action_check_premisetype
* thanks
    - utter_np
    - action_restart

## month_week 1
* month_week_result{"month": "october"}
    - utter_what_weekday
* out_of_scope
    - action_default_fallback
* inform{"weekday":"wednesday"}
    - action_month_week
* thanks
    - utter_np
    - action_restart
    
## month_week 2
* month_week_result{"month": "july", "weekday": "saturday"}
    - action_month_week
* thanks
    - utter_np
    - action_restart
    
## rank 1
* rank_result{"rank":"most frequent" ,"neighbor": "annex", "year_from": "2015","year_to": "2017"}
    - action_rank
* thanks
    - utter_np
    - action_restart
    
## rank 2
* rank_result{"rank":"top" ,"neighbor": "danforth"}
    - utter_what_year_range
* out_of_scope
  - action_default_fallback
* inform{"year_from": "2015","year_to": "2017"}
    - action_rank
* thanks
    - utter_np
    - action_restart

## rank 3
* rank_result{"rank":"worst"}
    - utter_what_neighbor
* out_of_scope
  - action_default_fallback
* inform{"neighbor": "university"}
    - utter_what_year_range
* out_of_scope
  - action_default_fallback
* inform{"year_from": "2015","year_to": "2017"}
    - action_rank
* thanks
    - utter_np
    - action_restart
    
## fallback story
* out_of_scope
  - action_default_fallback