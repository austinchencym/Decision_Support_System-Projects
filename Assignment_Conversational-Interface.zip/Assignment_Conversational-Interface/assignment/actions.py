from rasa_core_sdk import Action
import pandas as pd
import requests

crime_data = pd.read_csv("data/Toronto_MCI_2015_to_2017_new.csv")

class PremisetypeAction(Action):
    def name(self):
        return "action_check_premisetype"

    def run(self, dispatcher, tracker, domain):
        premisetype = tracker.get_slot('premisetype')

        premisetype_presence = len(crime_data[crime_data.premisetype == str(premisetype)]) > 0
        premisetype_occurrence = len(crime_data[crime_data.premisetype == str(premisetype)])

        if premisetype_presence is True:
            dispatcher.utter_message("Yes, there are crimes happend in/at the premise type of {}, specifically, {} cases!".format(premisetype, premisetype_occurrence))
        else:
            dispatcher.utter_message("According to the dataset, there is no crime happened in/at the premise type of {}!".format(premisetype))

class MonthYearAction(Action):
    def name(self):
        return "action_month_week"

    def run(self, dispatcher, tracker, domain):
        month = tracker.get_slot('month')
        weekday = tracker.get_slot('weekday')
        occurrence_month = len(crime_data[crime_data.occurrencemonth == str(month)])
        occurrence_day = len(crime_data[(crime_data.occurrencedayofweek == str(weekday)) & (crime_data.occurrencemonth == str(month))])
        dispatcher.utter_message("In {}, there are {} crimes happened in total, and {} of them happened on {}.".format(month, occurrence_month, occurrence_day, weekday))

class RankAction(Action):
    def name(self):
        return "action_rank"

    def run(self, dispatcher, tracker, domain):
        year_from = tracker.get_slot('year_from')
        year_to = tracker.get_slot('year_to')
        neighbor = tracker.get_slot('neighbor')

        crime_data_trim = crime_data[(crime_data.neighbourhood == str(neighbor))&(crime_data.occurrenceyear>=int(year_from))&(crime_data.occurrenceyear<=int(year_to))]
        top_crime = crime_data_trim['mci'].mode()[0]
        top_crime_count = crime_data_trim.groupby(['mci']).agg(['count']).values.max()
        total_crime_count = len(crime_data[crime_data.neighbourhood == str(neighbor)])
        top_crime_rate = top_crime_count/total_crime_count
        result_rate = round(top_crime_rate*100,2)

        dispatcher.utter_message("From {} to {}, the most frequent crime in neighborhood {} is {} with {} occurrences, accounting for {}% of total crime in the {} neighborhood.".format(year_from,year_to,neighbor,top_crime,top_crime_count,result_rate,neighbor))