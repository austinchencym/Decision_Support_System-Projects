## Sample Story
* greet
    - utter_greet
* results_query
    - utter_what_team
* inform{"team":"Arsenal"}
    - utter_what_season
* inform{"season":"1996-97"}
    - action_get_results
* thanks
    - utter_np
* goodbye
    - utter_goodbye